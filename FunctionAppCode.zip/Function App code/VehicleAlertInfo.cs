﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlertsEventHubTrigger
{
    internal class VehicleAlertInfo
    {
        public string VIN { get; set; }
        public DateTime Snapshot { get; set; }
        public float AverageEngineTemperature { get; set; }
        public float AverageSpeed { get; set; }
        public int HasAlert { get; set; }
    }
}
