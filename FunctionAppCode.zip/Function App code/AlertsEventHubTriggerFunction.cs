using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Messaging.EventHubs;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Azure;
using Azure.Communication.Email;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;

namespace AlertsEventHubTrigger
{
    public static class AlertsEventHubTriggerFunction
    {
        [FunctionName("AlertsEventHubTriggerFunction")]
        public static async Task Run([EventHubTrigger("alertseventhub", Connection = "eventhubconnectionstring")] EventData[] events, ILogger log)
        {
            var exceptions = new List<Exception>();
            string connectionString = ""; // Event hub end point url goes here
            var emailClient = new EmailClient(connectionString);


            foreach (EventData eventData in events)
            {
                try
                {
                    string messageBody = eventData.EventBody.ToString();

                    VehicleAlertInfo vehicleAlert = JsonConvert.DeserializeObject<VehicleAlertInfo>(messageBody);
                    var vin = vehicleAlert.VIN;
                    var snapshot = vehicleAlert.Snapshot;
                    var avgEngineTemp = vehicleAlert.AverageEngineTemperature; 
                    var avgSpeed = vehicleAlert.AverageSpeed;
                    var hasAlert = vehicleAlert.HasAlert;

                    var emailMessage = new EmailMessage(
                    senderAddress: "", //Sender email address
                    content: new EmailContent("Vehicle Engine High Temperature Alert")
                    {
                        PlainText = $"Vehicle Details: {vin} {snapshot} {avgEngineTemp} {avgSpeed} {hasAlert}",
                        Html = $"<strong>Vehicle Details: Vin:{vin} Timestamp:{snapshot} EngineTemperature:{avgEngineTemp} Speed:{avgSpeed} HasAlert:{hasAlert}</strong>",
                },
                    recipients: new EmailRecipients(new List<EmailAddress> { new EmailAddress("") })); //recipient email address
                        EmailSendOperation emailSendOperation = await emailClient.SendAsync(WaitUntil.Completed, emailMessage);

                        log.LogInformation($"C# Event Hub trigger function processed a message: {eventData.EventBody}");
                        await Task.Yield();
                }
                catch (Exception e)
                {
                    // We need to keep processing the rest of the batch - capture this exception and continue.
                    // Also, consider capturing details of the message that failed processing so it can be processed again later.
                    exceptions.Add(e);
                }
            }

            // Once processing of the batch is complete, if any messages in the batch failed processing throw an exception so that there is a record of the failure.

            if (exceptions.Count > 1)
                throw new AggregateException(exceptions);

            if (exceptions.Count == 1)
                throw exceptions.Single();
        }
    }
}
